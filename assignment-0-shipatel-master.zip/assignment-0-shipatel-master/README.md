# assignment-0
Mock assignment for practice
Shivani Patel